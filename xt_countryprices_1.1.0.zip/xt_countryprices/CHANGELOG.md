## [1.1.0]
- Installer
- FIX Anpassung PHP 8
