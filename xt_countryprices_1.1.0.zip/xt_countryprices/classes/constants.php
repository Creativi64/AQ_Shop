<?php

defined('_VALID_CALL') or die('Direct Access is not allowed.');

global $DB_PREFIX;

define('TABLE_PRODUCTS_PRICE_COUNTRY', $DB_PREFIX.'products_price_country');
