<?php

defined('_VALID_CALL') or die('Direct Access is not allowed.');

require_once _SRV_WEBROOT. _SRV_WEB_PLUGINS.'xt_countryprices/classes/constants.php';

echo '.products_country_price::before { content: "\f0ac"; font-family: "Font Awesome 5 Free"; font-style: normal; font-weight: 600;}';
