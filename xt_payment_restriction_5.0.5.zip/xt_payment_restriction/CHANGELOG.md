## [5.0.5]
- code fix 'called _getTotalOrderCount on null'

## [5.0.4]
- php8 code fix

## [5.0.3]
- Installer Fix